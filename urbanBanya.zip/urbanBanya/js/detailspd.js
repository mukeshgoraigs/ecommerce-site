﻿$(document).ready(function () {
    console.log("loadefddf");
});